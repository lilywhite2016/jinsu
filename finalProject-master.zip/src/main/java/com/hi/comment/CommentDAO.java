package com.hi.comment;

public class CommentDAO {

}
