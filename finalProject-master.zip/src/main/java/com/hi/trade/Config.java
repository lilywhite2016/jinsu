package com.hi.trade;

public final class Config {
	public static final String appid = "sson7909";
	public static final String apikey = "abed6baaf3a511e7ac9e0cc47a1fcfae";
	private String content = "";
	public static final String sender = "01056807909";
	private String receiver = "01000000000";
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	
	
}
