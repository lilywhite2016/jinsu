package com.hi.project.temp;

import org.springframework.stereotype.Repository;

@Repository
public class TempDAO {
	
}
