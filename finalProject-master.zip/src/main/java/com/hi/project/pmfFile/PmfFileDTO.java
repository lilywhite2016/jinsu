package com.hi.project.pmfFile;

import com.hi.file.FileDTO;

public class PmfFileDTO  extends FileDTO{

	private String filesize;

	public String getFilesize() {
		return filesize;
	}

	public void setFilesize(String filesize) {
		this.filesize = filesize;
	}
}
