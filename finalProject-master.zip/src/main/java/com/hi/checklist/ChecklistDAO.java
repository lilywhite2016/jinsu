package com.hi.checklist;

public class ChecklistDAO {

}
