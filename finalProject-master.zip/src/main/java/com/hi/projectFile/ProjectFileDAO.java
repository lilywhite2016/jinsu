package com.hi.projectFile;

import java.util.List;

import com.hi.file.FileDAO;
import com.hi.file.FileDTO;

public class ProjectFileDAO implements FileDAO{

	@Override
	public List<FileDTO> selectList(int num) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FileDTO selectOne(int fnum) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(FileDTO fileDTO) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(FileDTO fileDTO) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int fnum) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
