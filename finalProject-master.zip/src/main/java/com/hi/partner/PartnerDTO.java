package com.hi.partner;

public class PartnerDTO {

	private int schnum;
	private int pnum;
	private String nickname;
	
	public PartnerDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getSchnum() {
		return schnum;
	}
	public void setSchnum(int schnum) {
		this.schnum = schnum;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
}
