package com.hi.project;

import org.junit.Test;

public class ProjectTest extends AbstractTest {
/*	@Inject
	private ProjectService projectService;
	
	public void list(HttpSession session) {
		List<ProjectDTO> list = projectService.list(session);
		UsersDTO usersDTO = (UsersDTO)session.getAttribute("user");
		for(ProjectDTO dto : list) {
			System.out.println(dto.getProject_id());
			System.out.println(dto.getPrivacy());
			System.out.println(dto.getTitle());
			System.out.println(dto.getStar());
			System.out.println(dto.getStart_date());
			System.out.println(dto.getClose_date());
		}
	}*/
	
	@Test
	public void test() {
	}

}
